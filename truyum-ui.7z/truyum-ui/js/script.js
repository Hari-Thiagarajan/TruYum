var x="caution";
alert(x);